#include "monitor.hpp"

file_monitor::monitor::monitor() = default;
file_monitor::monitor::~monitor() = default;
